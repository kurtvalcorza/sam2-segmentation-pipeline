"""Review probes for sam2_segmentation_colab, torch-free (numpy + pillow).

P3  the generated sample: how much headroom the prompts leave. For each held-out record, the IoU of the filled
    prompt box (the notebook's "prompt-box baseline") and simple geometric facts (mask fill of its box,
    contrast). Shows why a pretrained promptable model sits at ~0.998 before any adaptation.
P4  the notebook's own BYOD helpers (cell 9 source, exec'd with the BYOD branch off) on constructed ZIPs.
"""
import io, json, sys, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(repo / "src"))
import sam2_segmentation_pipeline.pipeline as P

nb = json.loads((repo / "tutorials/sam2_segmentation_colab.ipynb").read_text())
cell = next("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code" and "USE_BYOD = False" in "".join(c["source"]))
ns = {"MIN_IMAGE_SIDE": P.MIN_IMAGE_SIDE, "MAX_IMAGE_SIDE": P.MAX_IMAGE_SIDE}
exec(compile(cell, "cell9", "exec"), ns)  # BYOD off: builds the 24 generated records and the split
res = {"split": {"train": len(ns["train_records"]), "held_out": len(ns["val_records"])}}

def box_iou(rec):
    m = rec["mask"]; x0, y0, x1, y1 = map(int, rec["box"])
    b = np.zeros_like(m); b[y0:y1, x0:x1] = True
    return float((m & b).sum() / (m | b).sum())
rows = []
for rec in ns["val_records"]:
    img = np.asarray(rec["image"]).astype(float); m = rec["mask"]
    rows.append({"id": rec["id"], "box_fill_iou": round(box_iou(rec), 4), "mask_pixels": int(m.sum()),
                 "fg_bg_mean_contrast": round(float(abs(img[m].mean() - img[~m].mean())), 1)})
res["P3_held_out"] = rows
res["P3_mean_box_fill_iou"] = round(float(np.mean([r["box_fill_iou"] for r in rows])), 6)
res["P3_validate"] = {k: v for k, v in P.validate_segmentation_dataset(ns["val_records"]).items() if k != "dataset_sha256"}

rng = np.random.default_rng(0)
def png(arr):
    b = io.BytesIO(); Image.fromarray(arr).save(b, "PNG"); return b.getvalue()
def rec_pair(i):
    img = rng.integers(0, 255, (64, 64, 3), dtype=np.uint8); m = np.zeros((64, 64), np.uint8); m[10:40, 12:50] = 255
    return png(img), png(m)
def zbytes(members):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in members.items(): z.writestr(k, v)
    return b.getvalue()
def pairs(n, prefix="", stem="s"):
    d = {}
    for i in range(n):
        im, m = rec_pair(i); d[f"{prefix}images/{stem}{i:02d}.png"] = im; d[f"{prefix}masks/{stem}{i:02d}.png"] = m
    return d
cases = {
    "ok_10": pairs(10),
    "wrapping_folder_10": pairs(10, prefix="mydata/"),
    "jpg_mask": {**pairs(9), "images/x.png": rec_pair(0)[0], "masks/x.jpg": rec_pair(0)[1]},
    "unmatched": {**pairs(9), "images/extra.png": rec_pair(0)[0]},
    "empty_mask": {**pairs(9), "images/e.png": rec_pair(0)[0], "masks/e.png": png(np.zeros((64, 64), np.uint8))},
    "traversal": {**pairs(9), "../evil.png": b"x"},
    "size_mismatch": {**pairs(9), "images/z.png": rec_pair(0)[0], "masks/z.png": png(np.zeros((32, 32), np.uint8) + 255)},
    "seven_pairs": pairs(7),
}
p4 = {}
for name, members in cases.items():
    try:
        recs = ns["records_from_zip"](zbytes(members))
        if len(recs) < 8:
            raise ValueError("E2E adaptation requires at least 8 records")  # the cell's next check, verbatim
        split_at = max(2, int(len(recs) * 0.75))
        p4[name] = {"accepted": True, "records": len(recs), "train_ids": [r["id"] for r in recs[:split_at]][:3] + ["…"], "held_out_ids": [r["id"] for r in recs[split_at:]]}
    except Exception as exc:
        p4[name] = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:220]}
res["P4"] = p4
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
